package com.google.gwt.dev.resource.impl.testdata.cpe1.org.example.foo.server;

public class FooServer {
  // test class
}