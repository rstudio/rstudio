package com.google.gwt.dev.resource.impl.testdata.cpe2.com.google.gwt.i18n.client;

public class Messages {
  // test class
}