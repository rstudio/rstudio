package com.google.gwt.dev.resource.impl.testdata.cpe1.org.example.foo.client;

public class FooClient {
  // test class
}