package com.google.gwt.dev.resource.impl.testdata.cpe1.com.google.gwt.user.client;

public class Command {
  // test class
}