package com.google.gwt.dev.resource.impl.testdata.cpe2.com.google.gwt.i18n.rebind;

public class LocalizableGenerator {
  // test class
}
